![OCR on Android](http://gaut.am/wp-content/uploads/2011/11/capture_3-300x225.jpg)

For more information, check this tutorial: http://gaut.am/making-an-ocr-android-app-using-tesseract/
