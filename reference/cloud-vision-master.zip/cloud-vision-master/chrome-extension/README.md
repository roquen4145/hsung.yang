# Google Cloud Vision Chrome Extension example

![status: inactive](https://img.shields.io/badge/status-inactive-red.svg)

The Google Cloud Vision API Chrome Extension example has moved.

For new work on this check out the Chrome extension in the [Machine Learning
Browser Extension
repository](https://github.com/GoogleCloudPlatform/machine-learning-browser-extension/tree/master/chrome)
