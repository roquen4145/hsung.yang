![status: inactive](https://img.shields.io/badge/status-inactive-red.svg)

The Google Cloud Vision API JavaScript (web browser) samples have moved. This
directory is no longer actively developed or maintained.

For new work on this check out the
[vision samples](https://github.com/GoogleCloudPlatform/web-docs-samples/tree/master/vision/explore-api)
in the Google Cloud Platform web samples repository.
