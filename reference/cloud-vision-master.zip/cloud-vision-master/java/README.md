![status: inactive](https://img.shields.io/badge/status-inactive-red.svg)

The Google Cloud Vision API Java samples have moved. This directory is no longer
actively developed or maintained.

For new work on this check out the
[vision samples](https://github.com/GoogleCloudPlatform/java-docs-samples/tree/master/vision)
in the Google Cloud Platform Java samples repository.
