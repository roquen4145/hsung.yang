# Cloud Vision iOS Samples

These apps demonstrate how to make an API call to the [Cloud Vision API](https://cloud.google.com/vision/), using a photo from the device photo library. Check out the [Swift](https://github.com/GoogleCloudPlatform/cloud-vision/tree/master/ios/Swift) or [Objective-C](https://github.com/GoogleCloudPlatform/cloud-vision/tree/master/ios/Objective-C) READMEs for full getting started instructions.
