./gradlew :camerafragment:install
./gradlew :camerafragment:bintrayUpload