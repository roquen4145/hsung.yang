# Tesseract Example

A very basic Tesseract-OCR example with C++ Archive Network building.

You can [try](https://github.com/cppan/tesseract_example/tree/master/with_cmake) it inside CMake project (see `with_cmake` dir) or [without](https://github.com/cppan/tesseract_example/tree/master/with_cppan) explicit CMake project (see `with_cppan` dir).
